document.getElementById("year").textContent = new Date().getFullYear();

function paymentNotice(method) {
  alert(method + " checkout is ready to be connected. Replace the payment button link in index.html with your live " + method + " payment link.");
  return false;
}
