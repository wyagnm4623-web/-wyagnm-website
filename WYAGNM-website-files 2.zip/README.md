# WYAGNM Website

Static HTML/CSS/JS website for WYAGNM — WHY YOU AIN'T GOT NO MOTION.

## Cloudflare Pages
- Framework preset: None
- Production branch: main
- Build command: `exit 0`
- Build output directory: `/` (repository root) once these files are uploaded
- Root directory: `/`

## Before launch
Replace the Stripe and PayPal button links in `index.html` with the live checkout links.

Contact:
Wyagnm4623@gmail.com

Instagram:
https://www.instagram.com/WYAGNM/
